import KakGamePreview from "../components/KakGamePreview";
export default function KakPage() {
  return <KakGamePreview />;
}
