// components/KakGamePreview.tsx
// Вставь сюда сгенерированный код из ChatGPT